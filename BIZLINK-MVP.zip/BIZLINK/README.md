# BIZLINK MVP

A responsive single-page marketplace prototype.

## Run locally
Open `index.html` in a modern browser. No build tools are required.

## Included
- Responsive dark landing page and service categories
- Project search and featured listings
- Business/provider signup and login (browser-local demo accounts)
- Business dashboard and project posting
- Provider dashboard, profile editing and offer submission
- Business offer review
- Pricing display: businesses €4.99/month, providers free

## Important before public launch
This is a front-end MVP prototype. Authentication and data are stored in browser localStorage, passwords are not securely handled, and data is not shared between users/devices. No real subscription payment is collected. Do not use real passwords or sensitive data.

Next production step: connect Supabase Auth + PostgreSQL, add Row Level Security policies, and deploy through Vercel. Add a payment provider only after the core marketplace is tested.
